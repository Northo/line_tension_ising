# Explanation of submission files

`code` contains code related to the exam
 - `code/utils.jl` contains the main part of the code
 - In `code/datadir` are som example data files.
 - `code/README.md` explains the code files
`assignment2` contains files related to assignment 2
`BALLESTAD_TFY4235_report.pdf` contains both the exam report and assignment 2
`report.pdf` is the report for the exam itself
