# Metropolis Monte Carlo using the Mon-Jasnow algorithm

`utils.jl` contains the main part of the code
`over_T_N.jl` is used for running simulations
`debug.jl` is used for having a quick script to run for debugging

The python scripts generate various figures.
